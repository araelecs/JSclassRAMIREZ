/**
 * here
 * is
 * another commment
 * with like a block thing
 * usually at the top of a page
 */


/*
more comment stuff
*/

// here is a comment in js
alert("illustrating comments");