alert("here is my alert yes yes yes");
console.log("here's the console loggggggg");