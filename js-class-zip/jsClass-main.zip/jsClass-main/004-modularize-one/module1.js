const myAlert = "hello world1111";
const myConsole = "hello world2222222";
export {myAlert, myConsole};