import {myAlert, myConsole} from "./module1.js";
alert(myAlert);
console.log(myConsole);